# VALIUM website starter

A responsive, single-page dark Y2K / emo-luxury jewelry storefront.

## Preview locally
1. Unzip the folder.
2. Open `index.html` in a modern browser. The product gallery, add-to-bag buttons, quantity controls, subtotal, and demo checkout modal work locally.
3. Internet is needed for the optional Google Fonts; the page still works without them.

## Before publishing
- Replace the placeholder jewelry illustrations and demo products/prices with real product photos, descriptions, inventory, and final prices.
- Replace `https://instagram.com/` with your actual brand Instagram profile.
- Replace `hello@valium.example` everywhere with a real email address.
- The cart and checkout are a front-end demo only. No real payments or orders are processed, and cart contents are not saved.
- To accept payments, connect a hosted checkout or ecommerce backend. For a low-cost start, consider a payment provider's hosted payment links and manually confirm orders, or use a platform such as Shopify / WooCommerce if you need inventory, shipping, and order management. Confirm Malaysian availability, fees, and business requirements before choosing.
- Add delivery, returns, privacy, terms, and contact details before taking orders.

## Free static hosting (example: GitHub Pages)
1. Create/sign into GitHub and make a new repository (for example, `valium-store`).
2. Upload `index.html` to the repository root.
3. Open repository **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for the published URL shown on the Pages settings screen. Test it on a phone.
6. A custom domain is optional and usually costs extra.

You can also deploy the folder using a static hosting service such as Netlify or Cloudflare Pages. Static hosting publishes the design, but it does not provide secure payment processing by itself.
